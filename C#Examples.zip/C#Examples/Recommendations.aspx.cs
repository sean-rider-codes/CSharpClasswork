﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Recommendations : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        decimal total = 0.0M;

        if(Session.Count != 0)
        {
            foreach(string keyName in Session.Keys)
            {
                ListBox1.Items.Add(keyName + "   " + Session[keyName]);

                total += Convert.ToDecimal(Session[keyName].ToString());
            }

            ListBox1.Items.Add("_____________________");
            ListBox1.Items.Add("Total: " + total.ToString("c"));
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ListBox1.Items.Add("*********************");

    }
}