﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Options : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "ID: " + Session.SessionID;
        Label2.Text = "Time Out: " + Session.Timeout;
        if(Session.Count != 0)
        {
            Label3.Text = Session.Count.ToString();
        }
    }

    protected void Submitbtn_Click(object sender, EventArgs e)
    {
        //Add data to the Session Cookies
        
        Session.Add(RadioButtonList1.SelectedItem.Text, RadioButtonList1.SelectedItem.Value);


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session.Add("ArtificialBookName", "200");

    }
}